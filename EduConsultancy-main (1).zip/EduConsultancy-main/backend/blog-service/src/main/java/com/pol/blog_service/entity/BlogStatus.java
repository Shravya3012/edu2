package com.pol.blog_service.entity;

public enum BlogStatus {
    DRAFT,
    PUBLISHED,
    ARCHIVED
}
