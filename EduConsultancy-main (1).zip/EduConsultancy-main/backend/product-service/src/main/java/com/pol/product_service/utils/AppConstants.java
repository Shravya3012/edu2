package com.pol.product_service.utils;

public class AppConstants {
    public final static String PAGE="0";
    public final static String SIZE="10";
    public final static String SORT_BY_COURSE_TITLE ="title";
    public final static String SORT_BY_CATEGORY_NAME ="name";
    public final static String ORDER="ASC";
}