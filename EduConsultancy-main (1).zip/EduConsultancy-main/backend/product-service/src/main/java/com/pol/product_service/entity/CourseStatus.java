package com.pol.product_service.entity;

public enum CourseStatus {
        ACTIVE,
        INACTIVE
}