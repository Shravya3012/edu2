package com.pol.product_service.exceptions;

import com.pol.product_service.exceptions.customExceptions.CategoryNotFoundException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {
}
