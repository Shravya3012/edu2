package com.pol.user_service.auth.model;

public enum UserRoleEnum {
    STUDENT,
    PARENT,
    ADMIN
}
