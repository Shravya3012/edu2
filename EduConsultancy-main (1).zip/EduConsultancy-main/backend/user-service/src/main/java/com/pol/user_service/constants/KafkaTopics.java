package com.pol.user_service.constants;

public class KafkaTopics {

    public static final String UserRegisteredTopic = "user-registered-topic";
    public static final String ForgotPasswordTopic = "forgot-password-topic";
}
